﻿#pragma warning disable CA1416
using Microsoft.Diagnostics.Tracing;
using Microsoft.Diagnostics.Tracing.Session;
using OpenTelemetry;
using OpenTelemetry.Exporter;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Threading;
using System.Xml;

namespace EventAgentUnified
{
    internal class Program
    {
        /* ── Sysmon ETW 설정 ─────────────────────────────────────────────── */
        private const string SysmonProvider = "Microsoft-Windows-Sysmon";
        private const ulong SysmonKeywords = ulong.MaxValue;
        private const TraceEventLevel SysmonLevel = TraceEventLevel.Informational;
        private const string SessionName = "EventAgent";

        // 제외할 Sysmon 이벤트 ID
        private static readonly int[] SysmonSkipIds = { };

        /* ── Security(EventLog) 설정 ─────────────────────────────────────── */
        private static readonly int[] SecurityEventIds =
            { 4624, 4625, 4648, 4672, 4663, 4697, 4698, 4699 };

        /* ── OpenTelemetry ───────────────────────────────────────────────── */
        private static readonly TracerProvider Otel =
            Sdk.CreateTracerProviderBuilder()
                .SetResourceBuilder(ResourceBuilder.CreateDefault().AddService("event-agent"))
                .AddSource("event.agent")
                .AddOtlpExporter(o =>
                {
                    o.Endpoint = new("http://localhost:4319"); 
                    o.Protocol = OtlpExportProtocol.Grpc;
                })
                .Build();

        private static readonly ActivitySource Src = new("event.agent");

        private static readonly ConcurrentDictionary<int, Activity> RootsByPid = new();
        private static readonly ConcurrentDictionary<int, int> LastParent = new();

        private static Activity? GetOrCreateRoot(int pid, int ppid = 0)
        {
            if (pid == 0) return null;

            if (!RootsByPid.TryGetValue(pid, out var root))
            {
                ActivityContext parentCtx = default;
                if (ppid != 0 && RootsByPid.TryGetValue(ppid, out var parentRoot) && parentRoot != null)
                    parentCtx = parentRoot.Context;

                root = Src.StartActivity($"process:{pid}", ActivityKind.Internal, parentCtx);
                if (root != null) RootsByPid[pid] = root;
            }
            return root;
        }

        private static void Main()
        {
            var id = WindowsIdentity.GetCurrent();
            if (id == null || !new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator))
            {
                Console.WriteLine("관리자 권한으로 실행해 주십시오.");
                return;
            }

            Console.OutputEncoding = System.Text.Encoding.UTF8;

            using var session = new TraceEventSession(SessionName) { StopOnDispose = true };
            session.EnableProvider(SysmonProvider, SysmonLevel, SysmonKeywords);
            session.Source.Dynamic.All += HandleSysmon;

            var etwThread = new Thread(() => session.Source.Process())
            { IsBackground = true, Name = "Sysmon-ETW-Thread" };
            etwThread.Start();

            using var secWatcher = StartSecurityWatcher();

            Console.WriteLine("Event Agent (Sysmon + Security) 실행 중 …  <Enter> 종료");
            Console.ReadLine();

            secWatcher.Enabled = false;
            session.Dispose();
            Otel.Dispose();
            etwThread.Join();
        }

        /* ────────────────────────────── Sysmon ──────────────────────────── */
        private static void HandleSysmon(TraceEvent ev)
        {
            int eid = (int)ev.ID;
            if (SysmonSkipIds.Contains(eid)) return;

            int pid = TryGetPayloadInt(ev, "ProcessId") ?? ev.ProcessID;
            int ppid = TryGetPayloadInt(ev, "ParentProcessId") ?? 0;
            if (pid == 0) return;

            if (ppid == 0 && LastParent.TryGetValue(pid, out var cached)) ppid = cached;
            if (ppid != 0) LastParent[pid] = ppid;

            var root = GetOrCreateRoot(pid, ppid);
            if (root == null) return;

            string? image = TryGetPayloadString(ev, "Image") ?? TryGetPayloadString(ev, "TargetImage");
            var spanName = BuildSpanName(image, eid);

            using var child = Src.StartActivity(spanName, ActivityKind.Internal, parentContext: root.Context);
            if (child != null) AddSysmonTags(child, ev, pid, ppid);

            // 디버깅 로그 
            Console.WriteLine($"[Sysmon] EID={(int)ev.ID} PID={pid} PPID={ppid}");

            // 종료 이벤트(EID=5)면 루트 정리
            if (eid == 5)
            {
                root.Stop();
                RootsByPid.TryRemove(pid, out _);
            }
        }

        private static string? TryGetPayloadString(TraceEvent ev, string field)
        {
            if (ev.PayloadNames?.Contains(field) == true)
            {
                try { return ev.PayloadByName(field)?.ToString(); } catch { }
            }
            return null;
        }

        private static int? TryGetPayloadInt(TraceEvent ev, string field)
        {
            if (ev.PayloadNames?.Contains(field) == true)
            {
                try
                {
                    object? val = ev.PayloadByName(field);
                    return val switch
                    {
                        int i => i,
                        long l => (int)l,
                        string s when int.TryParse(s, out var x) => x,
                        _ => (int?)null
                    };
                }
                catch { }
            }
            return null;
        }

        /* ───────────────────────────── Security ─────────────────────────── */
        private static EventLogWatcher StartSecurityWatcher()
        {
            string xpath = "*[System[(" + string.Join(" or ", SecurityEventIds.Select(id => $"EventID={id}")) + ")]]";
            var query = new EventLogQuery("Security", PathType.LogName, xpath)
            {
                TolerateQueryErrors = true,
                ReverseDirection = false
            };

            var watcher = new EventLogWatcher(query, null, false);
            watcher.EventRecordWritten += (_, e) =>
            {
                if (e.EventRecord == null) return;
                try { HandleSecurity(e.EventRecord); }
                finally { e.EventRecord.Dispose(); }
            };
            watcher.Enabled = true;
            Console.WriteLine("Security EventLogWatcher 시작됨.");
            return watcher;
        }

        private static void HandleSecurity(EventRecord rec)
        {
            using (rec)
            {
                int pid = 0, ppid = 0;
                string pidSource = "unknown";

                switch (rec.Id)
                {
                    case 4688: // 프로세스 생성
                        pid = ToPid(GetSecurityDataAny(rec, "NewProcessId", "ProcessId"));
                        ppid = ToPid(GetSecurityDataAny(rec, "ParentProcessId", "CreatorProcessId", "ProcessId"));
                        pidSource = (pid != 0) ? "clientpid" : "unknown";
                        break;

                    case 4689: // 프로세스 종료
                        pid = ToPid(GetSecurityDataAny(rec, "ProcessId", "NewProcessId"));
                        ppid = 0;
                        pidSource = "terminate";
                        break;

                    case 4697: // 서비스 설치
                        pid = ToPid(GetSecurityDataAny(rec, "ClientProcessId", "ProcessId", "CallerProcessId"));
                        ppid = ToPid(GetSecurityDataAny(rec, "ParentProcessId", "CallerParentProcessId"));
                        pidSource = (pid != 0) ? "clientpid" : "provider";
                        break;

                    // 로그인/권한/실패 등
                    case 4624:
                    case 4625:
                    case 4648:
                    case 4672:
                        pid = ToPid(GetSecurityDataAny(rec, "ProcessId", "ClientProcessId", "CallerProcessId"));
                        pidSource = (pid != 0) ? "clientpid" : "unknown";
                        break;

                    default:
                        pid = ToPid(GetSecurityDataAny(rec, "ProcessId", "ClientProcessId", "CallerProcessId"));
                        ppid = ToPid(GetSecurityDataAny(rec, "ParentProcessId", "CreatorProcessId", "CallerParentProcessId"));
                        pidSource = (pid != 0) ? "clientpid" : "unknown";
                        break;
                }

                if (pid == 0) pid = rec.ProcessId ?? 0;
                if (pid == 0) return;

                if (ppid == 0 && LastParent.TryGetValue(pid, out var cached)) ppid = cached;
                if (ppid != 0) LastParent[pid] = ppid;

                // 디버깅 로그
                Console.WriteLine($"[Security] EID={rec.Id} PID={pid} PPID={ppid} src={pidSource}");

                var root = GetOrCreateRoot(pid, ppid);
                if (root == null) return;

                var img = GetImageFromEventRecord(rec);
                var spanName = BuildSpanName(img, rec.Id);

                using var span = Src.StartActivity(spanName, ActivityKind.Internal, root.Context);
                if (span == null) return;

                AddETWTags(span, rec, pid, ppid);

                if (rec.Id == 4689)
                {
                    root.Stop();
                    RootsByPid.TryRemove(pid, out _);
                }
            }
        }

        /* ────── 스팬 네이밍 ────── */
        private static string BuildSpanName(string? imagePath, int eventId)
        {
            string name = "unknown";
            if (!string.IsNullOrWhiteSpace(imagePath))
            {
                try { name = Path.GetFileName(imagePath); } catch { name = imagePath!; }
                if (string.IsNullOrWhiteSpace(name)) name = imagePath!;
            }
            return $"{name}@evt:{eventId}";
        }

        private static string? GetImageFromEventRecord(EventRecord rec)
        {
            string? v = GetSecurityDataAny(rec, "NewProcessName", "Image", "ProcessName", "Application", "ServiceFileName");
            if (!string.IsNullOrWhiteSpace(v)) return v;

            var cmd = GetSecurityDataAny(rec, "CommandLine", "Command");
            if (!string.IsNullOrWhiteSpace(cmd))
            {
                var s = cmd.Trim();
                if (s.StartsWith("\""))
                {
                    int end = s.IndexOf('"', 1);
                    if (end > 1) return s.Substring(1, end - 1);
                }
                var first = s.Split(new[] { ' ' }, 2)[0];
                if (!string.IsNullOrWhiteSpace(first)) return first;
            }
            return null;
        }

        private static void AddSysmonTags(Activity span, TraceEvent ev, int pid, int ppid)
        {
            Tag(span, "channel", "Sysmon");
            Tag(span, "EventName", ev.EventName);
            Tag(span, "sysmon.ppid", ppid);
            Tag(span, "ID", (int)ev.ID);
            Tag(span, "TimeStamp", ev.TimeStamp);
            Tag(span, "sysmon.opcode", ev.Opcode);

            foreach (var n in ev.PayloadNames ?? Array.Empty<string>())
                try { Tag(span, n, ev.PayloadByName(n)); } catch { }
        }

        private static void AddETWTags(Activity span, EventRecord rec, int pid, int ppid)
        {
            Tag(span, "channel", rec.LogName ?? "Security");
            Tag(span, "proc.pid", pid);
            Tag(span, "proc.ppid", ppid);
            Tag(span, "event.id", rec.Id);
            Tag(span, "record.id", rec.RecordId);
            Tag(span, "time.created", rec.TimeCreated);
        }

        private static string? GetSecurityData(EventRecord rec, string fieldName)
        {
            try
            {
                var xml = new XmlDocument();
                xml.LoadXml(rec.ToXml());
                var node = xml.SelectSingleNode($"//*[local-name()='Data' and @Name='{fieldName}']");
                return string.IsNullOrWhiteSpace(node?.InnerText) ? null : node.InnerText;
            }
            catch { return null; }
        }

        private static string? GetSecurityDataAny(EventRecord rec, params string[] names)
        {
            foreach (var n in names)
            {
                var v = GetSecurityData(rec, n);
                if (!string.IsNullOrWhiteSpace(v)) return v;
            }
            return null;
        }

        private static int ToPid(string? s)
        {
            if (string.IsNullOrWhiteSpace(s)) return 0;
            var t = s.Trim();
            if (int.TryParse(t, NumberStyles.Integer, CultureInfo.InvariantCulture, out var dec)) return dec;
            if (t.StartsWith("0x", StringComparison.OrdinalIgnoreCase)) t = t[2..]; // ← t로 슬라이스
            return int.TryParse(t, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var hex) ? hex : 0;
        }

        private static void Tag(Activity span, string k, object? v)
        {
            if (v != null) span.SetTag(k, v);
        }
    }
}
